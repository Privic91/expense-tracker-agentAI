from mcp.server import MCPServer
from mcp.server.mcpserver.exceptions import ToolError
import database

mcp = MCPServer("Expense Tracker")
database.init_db()

@mcp.tool()
def get_total_spending() -> dict:
    """Return total spending recorded in the expense database."""
    try:
        return {"currency": "SGD", "total_spending": float(database.get_total_spending())}
    except Exception as error:
        raise ToolError(str(error))

@mcp.tool()
def get_category_summary() -> dict:
    """Return spending totals grouped by expense category."""
    try:
        return {"results": database.get_category_summary()}
    except Exception as error:
        raise ToolError(str(error))

@mcp.tool()
def get_person_summary() -> dict:
    """Return spending totals grouped by person."""
    try:
        return {"results": database.get_person_summary()}
    except Exception as error:
        raise ToolError(str(error))

@mcp.tool()
def search_expenses(keyword: str, limit: int = 10) -> dict:
    """Search expenses by description, category, or person."""
    try:
        rows = database.search_expenses(keyword=keyword, limit=limit)
        return {"keyword": keyword, "results": rows}
    except Exception as error:
        raise ToolError(str(error))

if __name__ == "__main__":
    print("Starting Expense Tracker MCP Server...")
    print("Database:", database.DB_FILE)
    print("MCP URL: http://127.0.0.1:8000/mcp")
    mcp.run(transport="streamable-http", host="127.0.0.1", port=8000, json_response=True)
