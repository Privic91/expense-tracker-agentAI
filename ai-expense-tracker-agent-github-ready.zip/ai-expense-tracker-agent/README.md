# AI Expense Tracker Agent

A learning project that builds an expense tracker from a desktop form through SQLite, Model Context Protocol (MCP), a rule-based agent, and an optional LLM-powered agent.

## Architecture

```text
Tkinter Expense Form
        |
        v
Automatic Categorization
        |
        v
SQLite (expenses.db)
        |
        v
database.py
        |
        v
MCP Server
   |    |    |    |
   v    v    v    v
Total Category Person Search
        |
        v
Rule-based Agent
        |
        +--> Optional MiniMax LLM Agent
```

## Files

- `september_expense_form.py` — Tkinter expense-entry form for September 2026.
- `database.py` — SQLite database functions.
- `mcp_server.py` — exposes expense operations as MCP tools.
- `mcp_client.py` — direct MCP test client.
- `agent.py` — rule-based natural-language router over MCP.
- `llm_agent.py` — optional MiniMax-powered tool-selection agent.
- `requirements.txt` — Python dependencies.
- `.gitignore` — excludes secrets and private financial data.
- `data/sample_expense.csv` — fake sample data only.

## Setup

Python 3.10+ is recommended.

```bash
python -m venv .venv
```

Windows:

```bat
.venv\Scripts\activate
python -m pip install -r requirements.txt
```

## 1. Initialize the database

```bash
python database.py
```

This creates `data/expenses.db`. The database is ignored by Git because it may contain personal financial information.

## 2. Run the expense form

```bash
python september_expense_form.py
```

The form validates September 2026 dates, categorizes the expense, saves it to SQLite, and displays saved records.

## 3. Run the MCP server

```bash
python mcp_server.py
```

Default endpoint:

```text
http://127.0.0.1:8000/mcp
```

Current MCP tools:

- `get_total_spending`
- `get_category_summary`
- `get_person_summary`
- `search_expenses`

If port 8000 is occupied on Windows:

```bat
netstat -ano | findstr :8000
```

## 4. Test MCP directly

Open another terminal:

```bash
python mcp_client.py
```

The client lists tools and tests total spending, category summary, person summary, and an NTUC search.

## 5. Run the rule-based agent

```bash
python agent.py
```

Example questions:

```text
what is total spending
who spent the most
show spending by category
show spending by person
show ntuc expenses
show shell expenses
find hospital transactions
```

This agent is intentionally rule-based so the Agent -> MCP -> SQLite chain can be tested before adding an LLM.

## 6. Optional MiniMax LLM agent

`llm_agent.py` uses MiniMax to choose the MCP tool, supply tool arguments, and write a final response.

Set the API key locally rather than committing it:

Command Prompt:

```bat
set MINIMAX_API_KEY=YOUR_KEY
python llm_agent.py
```

PowerShell:

```powershell
$env:MINIMAX_API_KEY="YOUR_KEY"
python llm_agent.py
```

If MiniMax returns status `1008` / `insufficient balance`, the request reached MiniMax but the account does not currently have usable API balance or quota.

## Expense categories

The form currently supports:

- Groceries
- Transport
- Fuel
- Class
- Education
- Entertainment
- Gift
- Cleaning
- Meat & Seafood
- Dining
- Subscriptions
- Shopping
- Utilities
- Healthcare
- Other

## Security

Do **not** commit:

- API keys
- `.env` files
- `expenses.db`
- real bank CSVs
- receipts
- personal financial exports

Only fake sample data should be stored in a public repository.

## Completed milestones

- [x] Rule-based categorizer
- [x] Tkinter expense form
- [x] Person field
- [x] SQLite persistence
- [x] Total spending calculation
- [x] Category summary
- [x] Person summary
- [x] Expense search
- [x] MCP server
- [x] MCP test client
- [x] Rule-based agent
- [x] MiniMax LLM agent prototype
- [ ] Duplicate detection
- [ ] Monthly/date-range filtering
- [ ] Budget tracking
- [ ] Local/private LLM option
- [ ] Automated tests
- [ ] Dashboard/reporting layer

## Notes

This is a learning project. Before using it with real bank exports, add duplicate protection, stronger validation, backups, and privacy controls.
