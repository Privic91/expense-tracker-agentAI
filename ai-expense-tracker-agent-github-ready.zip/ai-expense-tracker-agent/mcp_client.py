import asyncio
import json
from mcp import Client

MCP_URL = "http://127.0.0.1:8000/mcp"

def display_result(result):
    if result.is_error:
        print("MCP TOOL ERROR")
        for block in result.content:
            if getattr(block, "type", None) == "text":
                print(block.text)
        return
    if result.structured_content is not None:
        print(json.dumps(result.structured_content, indent=2))
        return
    for block in result.content:
        if getattr(block, "type", None) == "text":
            print(block.text)

async def main():
    async with Client(MCP_URL) as client:
        tools_result = await client.list_tools()
        print("AVAILABLE MCP TOOLS")
        for tool in tools_result.tools:
            print("-", tool.name)
        tests = [
            ("get_total_spending", {}),
            ("get_category_summary", {}),
            ("get_person_summary", {}),
            ("search_expenses", {"keyword": "ntuc", "limit": 10}),
        ]
        for tool_name, arguments in tests:
            print("\n", tool_name.upper(), sep="")
            result = await client.call_tool(tool_name, arguments)
            display_result(result)

if __name__ == "__main__":
    asyncio.run(main())
