import asyncio
import json
import os
import requests
from mcp import Client

MCP_URL = "http://127.0.0.1:8000/mcp"
MINIMAX_URL = "https://api.minimax.io/v1/text/chatcompletion_v2"
MODEL = "MiniMax-M3"
API_KEY = os.getenv("MINIMAX_API_KEY", "")


def call_llm(messages):
    if not API_KEY:
        raise RuntimeError("MINIMAX_API_KEY is not set.")

    response = requests.post(
        MINIMAX_URL,
        headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
        json={"model": MODEL, "messages": messages},
        timeout=120,
    )

    if not response.ok:
        raise RuntimeError(f"MiniMax HTTP error {response.status_code}: {response.text}")

    data = response.json()
    base_resp = data.get("base_resp", {})
    status_code = base_resp.get("status_code", 0)
    status_msg = base_resp.get("status_msg", "")

    if status_code != 0:
        if status_code == 1008:
            raise RuntimeError("MiniMax API returned insufficient balance.")
        raise RuntimeError(f"MiniMax API error {status_code}: {status_msg}")

    choices = data.get("choices")
    if not choices:
        raise RuntimeError("MiniMax returned no model response.")

    content = choices[0].get("message", {}).get("content")
    if content is None:
        raise RuntimeError("MiniMax response did not contain message content.")
    return content


def extract_mcp_result(result):
    if result.is_error:
        messages = [block.text for block in result.content if getattr(block, "type", None) == "text"]
        return {"error": True, "message": " ".join(messages)}
    if result.structured_content is not None:
        return result.structured_content
    for block in result.content:
        if getattr(block, "type", None) == "text":
            try:
                return json.loads(block.text)
            except json.JSONDecodeError:
                return block.text
    return None


def build_tool_information(tools_result):
    return [
        {
            "name": tool.name,
            "description": tool.description or "",
            "input_schema": getattr(tool, "inputSchema", {}) or {},
        }
        for tool in tools_result.tools
    ]


def parse_tool_decision(text):
    text = text.strip().replace("```json", "").replace("```", "").strip()
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError("LLM did not return a valid JSON tool decision.")
    return json.loads(text[start:end + 1])


async def choose_mcp_tool(question, tools):
    system_prompt = f"""
You are the tool-selection component of an expense tracker.
Available MCP tools:
{json.dumps(tools, indent=2, default=str)}
Choose the best tool and matching arguments. Return JSON only:
{{"tool": "tool_name", "arguments": {{}}}}
For search_expenses, extract only the useful search keyword.
If no tool applies, return {{"tool": null, "arguments": {{}}}}.
"""
    text = await asyncio.to_thread(
        call_llm,
        [{"role": "system", "content": system_prompt}, {"role": "user", "content": question}],
    )
    return parse_tool_decision(text)


async def create_final_answer(question, tool_name, tool_result):
    prompt = f"""
Answer the expense question using only this MCP result.
Question: {question}
Tool: {tool_name}
Result: {json.dumps(tool_result, indent=2, default=str)}
Currency is SGD unless stated otherwise. Do not invent data.
"""
    return await asyncio.to_thread(
        call_llm,
        [{"role": "system", "content": "You are a concise expense tracker assistant."},
         {"role": "user", "content": prompt}],
    )


async def ask_agent(question):
    async with Client(MCP_URL) as client:
        tools_result = await client.list_tools()
        tools = build_tool_information(tools_result)
        available = [tool["name"] for tool in tools]
        decision = await choose_mcp_tool(question, tools)
        tool_name = decision.get("tool")
        arguments = decision.get("arguments", {})

        if tool_name is None:
            return "I could not find an appropriate expense tool for that question."
        if tool_name not in available:
            return f"The LLM selected an unavailable MCP tool: {tool_name}"

        print("LLM selected tool:", tool_name)
        print("Tool arguments:", arguments)
        result = await client.call_tool(tool_name, arguments)
        tool_result = extract_mcp_result(result)

        if isinstance(tool_result, dict) and tool_result.get("error") is True:
            return f"MCP tool error: {tool_result.get('message')}"

        return await create_final_answer(question, tool_name, tool_result)


async def main():
    print("AI Expense Tracker Agent")
    print("Model:", MODEL)
    print("Type 'exit' to stop.\n")
    while True:
        question = input("You: ").strip()
        if question.lower() == "exit":
            print("Agent stopped.")
            break
        try:
            print("\nAgent:")
            print(await ask_agent(question))
            print()
        except RuntimeError as error:
            print("\nLLM error:", error, "\n")
        except requests.RequestException as error:
            print("\nNetwork/API request error:", error, "\n")
        except Exception as error:
            print("\nAgent error:", type(error).__name__, str(error), "\n")


if __name__ == "__main__":
    asyncio.run(main())
