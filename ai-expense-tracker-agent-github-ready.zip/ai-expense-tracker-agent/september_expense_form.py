import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import database

database.init_db()


def categorize_expense(description):
    text = str(description).lower().strip()
    rules = {
        "Groceries": ["fairprice", "ntuc", "cold storage", "sheng siong", "seng siong", "grocery", "supermarket"],
        "Transport": ["grab", "gojek", "taxi", "mrt", "bus"],
        "Fuel": ["shell", "esso", "caltex", "petrol", "fuel"],
        "Class": ["swimming", "fitness", "dance", "yoga"],
        "Education": ["fees vishaan", "school trip", "schooltrip", "stationery", "books", "education", "school fee"],
        "Entertainment": ["movie", "cinema", "play activity", "entertainment"],
        "Gift": ["gift", "toys"],
        "Cleaning": ["helper", "aircon", "air con", "ac service", "cleaning"],
        "Meat & Seafood": ["chicken", "mutton", "fish", "seafood", "butcher"],
        "Dining": ["starbucks", "restaurant", "cafe", "mcdonald", "kfc", "foodpanda", "deliveroo", "coffee", "snacks", "hotel"],
        "Subscriptions": ["netflix", "spotify", "youtube", "icloud", "microsoft", "disney"],
        "Shopping": ["amazon", "shopee", "lazada", "uniqlo", "ikea", "zara"],
        "Utilities": ["electricity", "water", "singtel", "starhub", "sp services", "sp group"],
        "Healthcare": ["clinic", "hospital", "pharmacy", "guardian", "watsons", "medical", "doctor"],
    }
    for category, keywords in rules.items():
        for keyword in keywords:
            if keyword in text:
                return category
    return "Other"


def preview_category(event=None):
    description = description_entry.get().strip()
    category_var.set(categorize_expense(description) if description else "Enter description")


def save_expense():
    date_text = date_entry.get().strip()
    description = description_entry.get().strip()
    person = person_entry.get().strip()
    amount_text = amount_entry.get().strip()

    try:
        transaction_date = datetime.strptime(date_text, "%d/%m/%Y")
    except ValueError:
        messagebox.showerror("Invalid Date", "Please use DD/MM/YYYY format.")
        return

    if transaction_date.month != 9 or transaction_date.year != 2026:
        messagebox.showerror("Invalid Date", "Please enter a date in September 2026.")
        return
    if not description:
        messagebox.showerror("Missing Description", "Please enter an expense description.")
        return
    if not person:
        messagebox.showerror("Missing Person", "Please enter the person's name.")
        return

    try:
        amount = float(amount_text)
        if amount <= 0:
            raise ValueError
    except ValueError:
        messagebox.showerror("Invalid Amount", "Enter a positive amount.")
        return

    category = categorize_expense(description)
    try:
        database.insert_expense(
            transaction_date=transaction_date.strftime("%Y-%m-%d"),
            description=description,
            person=person,
            amount=amount,
            category=category,
            currency="SGD",
            source="Manual Form",
        )
    except Exception as error:
        messagebox.showerror("Database Error", str(error))
        return

    expense_table.insert("", "end", values=(
        transaction_date.strftime("%Y-%m-%d"), description, person, f"{amount:.2f}", category
    ))
    description_entry.delete(0, tk.END)
    person_entry.delete(0, tk.END)
    amount_entry.delete(0, tk.END)
    category_var.set("Enter description")
    description_entry.focus()


def load_existing_expenses():
    for row in database.get_all_expenses():
        expense_table.insert("", "end", values=(
            row["transaction_date"], row["description"], row["person"], f'{row["amount"]:.2f}', row["category"]
        ))


root = tk.Tk()
root.title("September 2026 Expense Tracker")
root.geometry("850x650")
category_var = tk.StringVar(master=root, value="Enter description")

tk.Label(root, text="September 2026 Expense Tracker", font=("Arial", 18, "bold")).pack(pady=20)
form_frame = ttk.Frame(root)
form_frame.pack(padx=30, pady=10)

labels = ["Date", "Description", "Person", "Amount (SGD)", "Automatic Category"]
for i, text in enumerate(labels):
    ttk.Label(form_frame, text=text).grid(row=i, column=0, sticky="w", padx=10, pady=10)

date_entry = ttk.Entry(form_frame, width=30)
date_entry.grid(row=0, column=1, padx=10, pady=10)
date_entry.insert(0, "03/09/2026")
description_entry = ttk.Entry(form_frame, width=30)
description_entry.grid(row=1, column=1, padx=10, pady=10)
description_entry.bind("<KeyRelease>", preview_category)
person_entry = ttk.Entry(form_frame, width=30)
person_entry.grid(row=2, column=1, padx=10, pady=10)
amount_entry = ttk.Entry(form_frame, width=30)
amount_entry.grid(row=3, column=1, padx=10, pady=10)
tk.Label(form_frame, textvariable=category_var, font=("Arial", 11, "bold")).grid(row=4, column=1, sticky="w", padx=10, pady=10)

ttk.Button(root, text="Save Expense", command=save_expense).pack(pady=20)

table_frame = ttk.Frame(root)
table_frame.pack(fill="both", expand=True, padx=20, pady=10)
columns = ("date", "description", "person", "amount", "category")
expense_table = ttk.Treeview(table_frame, columns=columns, show="headings", height=12)
for col, heading in zip(columns, ["Date", "Description", "Person", "Amount", "Category"]):
    expense_table.heading(col, text=heading)
expense_table.column("date", width=100)
expense_table.column("description", width=240)
expense_table.column("person", width=120)
expense_table.column("amount", width=100)
expense_table.column("category", width=140)
expense_table.pack(fill="both", expand=True)

load_existing_expenses()
root.mainloop()
