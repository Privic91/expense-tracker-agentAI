import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FOLDER = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_FOLDER, exist_ok=True)
DB_FILE = os.path.join(DATA_FOLDER, "expenses.db")


def get_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transaction_date TEXT NOT NULL,
                description TEXT NOT NULL,
                person TEXT NOT NULL,
                amount REAL NOT NULL,
                category TEXT NOT NULL,
                currency TEXT DEFAULT 'SGD',
                source TEXT DEFAULT 'Manual Form',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
    finally:
        conn.close()


def insert_expense(transaction_date, description, person, amount, category,
                   currency="SGD", source="Manual Form"):
    conn = get_connection()
    try:
        conn.execute("""
            INSERT INTO expenses
            (transaction_date, description, person, amount, category, currency, source)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (transaction_date, description, person, amount, category, currency, source))
        conn.commit()
    finally:
        conn.close()


def get_all_expenses():
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT * FROM expenses
            ORDER BY transaction_date DESC, id DESC
        """).fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()


def get_total_spending():
    conn = get_connection()
    try:
        row = conn.execute("SELECT COALESCE(SUM(amount), 0) AS total FROM expenses").fetchone()
        return round(float(row["total"]), 2)
    finally:
        conn.close()


def get_category_summary():
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT category, ROUND(SUM(amount), 2) AS total, COUNT(*) AS transactions
            FROM expenses
            GROUP BY category
            ORDER BY total DESC
        """).fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()


def get_person_summary():
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT person, ROUND(SUM(amount), 2) AS total, COUNT(*) AS transactions
            FROM expenses
            GROUP BY person
            ORDER BY total DESC
        """).fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()


def search_expenses(keyword, limit=10):
    conn = get_connection()
    search = f"%{keyword}%"
    try:
        rows = conn.execute("""
            SELECT * FROM expenses
            WHERE description LIKE ? OR category LIKE ? OR person LIKE ?
            ORDER BY transaction_date DESC, id DESC
            LIMIT ?
        """, (search, search, search, int(limit))).fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()


if __name__ == "__main__":
    init_db()
    print("Database ready:")
    print(DB_FILE)
