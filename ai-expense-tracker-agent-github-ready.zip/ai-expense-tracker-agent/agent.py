import asyncio
import json
import re
from mcp import Client

MCP_URL = "http://127.0.0.1:8000/mcp"


def extract_result(result):
    if result.is_error:
        messages = []
        for block in result.content:
            if getattr(block, "type", None) == "text":
                messages.append(block.text)
        return {"error": True, "message": " ".join(messages)}

    if result.structured_content is not None:
        data = result.structured_content
        if isinstance(data, dict) and "result" in data and len(data) == 1:
            return data["result"]
        return data

    for block in result.content:
        if getattr(block, "type", None) == "text":
            try:
                data = json.loads(block.text)
                if isinstance(data, dict) and "result" in data and len(data) == 1:
                    return data["result"]
                return data
            except json.JSONDecodeError:
                return block.text
    return None


def extract_search_keyword(question):
    text = question.lower().strip().replace("related to", " ")
    text = re.sub(
        r"\b(show|find|search|expenses?|transactions?|for|about|my)\b",
        " ",
        text,
    )
    return " ".join(text.split())


def choose_tool(question):
    text = question.lower().strip()

    if any(p in text for p in ["who spent the most", "highest spender", "spent most", "top spender"]):
        return {"tool": "get_person_summary", "intent": "highest_spender", "arguments": {}}

    if any(p in text for p in ["each person", "by person", "person summary", "people summary", "spending by person"]):
        return {"tool": "get_person_summary", "intent": "person_summary", "arguments": {}}

    if any(p in text for p in ["by category", "category summary", "categories", "spending by category"]):
        return {"tool": "get_category_summary", "intent": "category_summary", "arguments": {}}

    if any(p in text for p in ["total spending", "how much spent", "how much did we spend", "overall spending", "total expense"]):
        return {"tool": "get_total_spending", "intent": "total_spending", "arguments": {}}

    if text.startswith(("show ", "find ", "search ")):
        keyword = extract_search_keyword(question)
        if keyword:
            return {
                "tool": "search_expenses",
                "intent": "search_expenses",
                "arguments": {"keyword": keyword, "limit": 10},
            }

    return None


def format_answer(intent, data):
    if intent == "total_spending":
        total = float(data.get("total_spending", 0))
        return f"Total spending is {data.get('currency', 'SGD')} {total:.2f}"

    if intent == "highest_spender":
        rows = data.get("results", [])
        if not rows:
            return "No expense data found."
        highest = rows[0]
        return (
            f"{highest['person']} spent the most: SGD {float(highest['total']):.2f} "
            f"across {highest['transactions']} transactions."
        )

    if intent == "person_summary":
        rows = data.get("results", [])
        if not rows:
            return "No expense data found."
        answer = "\nPERSON SUMMARY\n"
        for row in rows:
            answer += f"{row['person']}: SGD {float(row['total']):.2f} ({row['transactions']} transactions)\n"
        return answer

    if intent == "category_summary":
        rows = data.get("results", [])
        if not rows:
            return "No expense data found."
        answer = "\nCATEGORY SUMMARY\n"
        for row in rows:
            answer += f"{row['category']}: SGD {float(row['total']):.2f} ({row['transactions']} transactions)\n"
        return answer

    if intent == "search_expenses":
        rows = data.get("results", [])
        if not rows:
            return "No matching expenses found."
        answer = "\nMATCHING EXPENSES\n"
        total = 0.0
        for row in rows:
            amount = float(row["amount"])
            total += amount
            answer += (
                f"{row['transaction_date']} | {row['description']} | {row['person']} | "
                f"SGD {amount:.2f} | {row['category']}\n"
            )
        answer += f"\nTotal for matching expenses: SGD {total:.2f}"
        return answer

    return str(data)


async def ask_agent(question):
    decision = choose_tool(question)
    if decision is None:
        return (
            "I currently understand questions about total spending, category summary, "
            "person summary, highest spender, and expense searches."
        )

    async with Client(MCP_URL) as client:
        tools_result = await client.list_tools()
        available_tools = [tool.name for tool in tools_result.tools]
        tool_name = decision["tool"]

        if tool_name not in available_tools:
            return f"MCP tool '{tool_name}' is not available."

        result = await client.call_tool(tool_name, decision["arguments"])
        data = extract_result(result)

        if isinstance(data, dict) and data.get("error") is True:
            return f"MCP tool error: {data.get('message')}"

        return format_answer(decision["intent"], data)


async def main():
    print("Expense Tracker Agent")
    print("Type 'exit' to stop.\n")
    while True:
        question = input("You: ").strip()
        if question.lower() == "exit":
            print("Agent stopped.")
            break
        try:
            print("\nAgent:")
            print(await ask_agent(question))
            print()
        except Exception as error:
            print("\nAgent error:", type(error).__name__, str(error), "\n")


if __name__ == "__main__":
    asyncio.run(main())
